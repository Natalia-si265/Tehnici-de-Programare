L4 - Functii, metode si importuri pe web
Volcova Natalia, SI-265

PORNIRE IN PYCHARM
1. Extrag arhiva ZIP.
2. In PyCharm aleg File > Open si selectez folderul web_lab.
3. Selectez un interpretor Python 3.9 sau mai nou daca mi se cere.
4. Deschid Terminal (din partea de jos) si scriu:
   python -m pip install -r requirements.txt
5. Din acelasi terminal rulez:
   python main.py https://cybercor.org

Pot rula main.py si cu click dreapta > Run. Fara argument foloseste
tot https://cybercor.org. Terminalul se afla in folderul web_lab.

EXERCITII
python part1_imports.py     exercitiile 1-8
python part2_methods.py     exercitiile 9-20
python part3_functions.py   exercitiile 21-34
python part4_modules.py     exercitiile 35-43
python main.py https://cybercor.org   exercitiile 44-50
python webtools.py         autotestul exercitiului 46

Functiile reutilizabile sunt in webtools.py, dupa mutarea ceruta la ex. 44.
Fiecare parte contine apelurile si comentariile pentru exercitiile ei.
Rularea poate dura deoarece am pus pauze si timeout la cereri.
Pentru bonusul optional, beautifulsoup4 nu este necesar versiunii de baza.

FISIERE GENERATE
main.py creeaza report.csv si report.json in folderul web_lab.
part4_modules.py creeaza si headers.json.
Valorile sunt obtinute la rulare si se pot schimba in timp.
None/null intr-un raport inseamna ca informatia nu a putut fi obtinuta;
mesajul concret se afla in errors. Nu inseamna un scor zero.
Rulez programul pe calculatorul meu pentru rezultate din conexiunea mea.

REGULI
Pe cybercor.org folosesc doar GET/HEAD pentru caile din enunt.
Nu vizitez legaturile extrase sau caile Disallow.
Antetul personalizat este trimis numai la httpbin.org.
Ex. 47 este aplicat tinand cont de regula generala a laboratorului:
DEFAULT_HEADERS este folosit in fetch numai pentru httpbin.org.

PREDARE
Pun folderul web_lab intr-o arhiva:
L4_TP_Volcova_Natalia_SI-265.zip
Email: cristian.gonceari@isa.utm.md
Subiect: L4_TP_Volcova_Natalia_SI-265
Atasament: o singura arhiva ZIP.

SURSE CONSULTATE
Enuntul L4_Laborator_Python_Web.docx.
https://requests.readthedocs.io/en/latest/user/quickstart/
https://docs.python.org/3/library/ssl.html
