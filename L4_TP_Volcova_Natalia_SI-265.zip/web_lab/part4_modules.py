# Laborator: functii, metode si importuri pe web
# Student: Volcova Natalia, SI-265
BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10

import json
from urllib.parse import urlparse, urljoin
from webtools import (fetch, extract_links, split_links, ImageFinder,
                      page_fingerprint, resolve, cert_days_left,
                      FOLDER, run_exercise)


def exercise_35():
    """Descompun URL-ul, fara sa trimit o cerere spre acesta."""
    parts = urlparse("https://cybercor.org/path?x=1#top")
    print("schema:", parts.scheme)
    print("domeniu:", parts.netloc)
    print("cale:", parts.path)
    print("interogare:", parts.query)
    print("fragment:", parts.fragment)


def exercise_36():
    """Compun adresele, fara sa accesez paginile rezultate."""
    for link in ["/about", "contact.html", "../index.html"]:
        print(urljoin(BASE_URL, link))


def exercise_37():
    """Extrag legaturile fara duplicate."""
    response = fetch(BASE_URL)
    links = extract_links(response.text)
    print("Legaturi unice:", len(links))
    for link in links:
        print(link)


def exercise_38():
    """Separ adresele interne de cele externe, fara sa le vizitez."""
    response = fetch(BASE_URL)
    links = extract_links(response.text)
    internal, external = split_links(links, BASE_URL)
    print("Interne:", len(internal))
    print("Externe:", len(external))


def exercise_39():
    """Testez mai intai parserul cu HTML cunoscut, apoi pe site."""
    test_html = '''
    <html><body>
      <img src="/logo.png" alt="Logo">
      <IMG SRC="poza.jpg">
      <img alt="imagine fara src">
      <img src="https://cdn.example.com/banner.webp" />
      <a href="/despre">Aceasta nu este o imagine</a>
    </body></html>
    '''
    finder = ImageFinder()
    finder.feed(test_html)
    print(finder.images)
    assert finder.images == [
        "/logo.png", "poza.jpg", "https://cdn.example.com/banner.webp"
    ], "Parserul nu a gasit exact imaginile asteptate"
    print("Testul a trecut!")
    response = fetch(BASE_URL)
    finder = ImageFinder()
    finder.feed(response.text)
    print(len(finder.images), "imagini gasite")
    for src in finder.images:
        print(src)
    print("Aparitii <img in sursa:", response.text.lower().count("<img"))
    # feed citeste HTML si apeleaza singur handle_starttag pentru fiecare tag.
    # Un tag img fara src apare in count, dar nu este pus in lista images.
    # Pentru a compara manual, deschid pagina si folosesc Ctrl+U in browser.


def exercise_40():
    """Calculez amprenta de doua ori si compar."""
    first = page_fingerprint(BASE_URL)
    second = page_fingerprint(BASE_URL)
    print(first)
    print(second)
    print("Identice:", first == second)
    # Daca se schimba continutul, inclusiv un singur octet, amprenta se schimba.
    # O pagina dinamica poate avea amprente diferite intre doua descarcari.


def exercise_41():
    """Salvez antetele ca JSON si le citesc inapoi."""
    response = fetch(BASE_URL)
    with open(FOLDER / "headers.json", "w", encoding="utf-8") as file:
        json.dump(dict(response.headers), file, indent=2)
    with open(FOLDER / "headers.json", "r", encoding="utf-8") as file:
        headers = json.load(file)
    # Dupa json.load am un dict obisnuit, cu chei care depind de majuscule.
    for name, value in headers.items():
        if name.lower() == "content-type":
            print("Content-Type citit din JSON:", value)


def exercise_42():
    """Afisez adresa IP obtinuta prin DNS."""
    print("IP:", resolve("cybercor.org"))


def exercise_43():
    """Afisez zilele ramase pana la expirarea certificatului."""
    print("Zile ramase:", cert_days_left("cybercor.org"))


if __name__ == "__main__":
    exercises = [exercise_35, exercise_36, exercise_37, exercise_38,
                 exercise_39, exercise_40, exercise_41, exercise_42, exercise_43]
    for number, exercise in enumerate(exercises, 35):
        run_exercise(number, exercise)
