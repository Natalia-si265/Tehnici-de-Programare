# Laborator: functii, metode si importuri pe web
# Student: Volcova Natalia, SI-265
BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10

import requests
import time
from webtools import fetch, run_exercise


def exercise_9(response):
    """Afisez atributele raspunsului."""
    print(response.status_code)  # atribut: codul de stare
    print(response.ok)           # atribut: codul este mai mic decat 400
    print(response.url)          # atribut: URL-ul final
    print(response.encoding)     # atribut: codificarea textului


def exercise_10(response):
    """Folosesc metoda raise_for_status si prind HTTPError."""
    response.raise_for_status()
    # La rularea mea, calea inexistenta a primit tot codul 200.
    # De aceea raise_for_status() nu a produs HTTPError.
    missing = fetch(BASE_URL + "/this-page-does-not-exist")
    try:
        missing.raise_for_status()
        print("Pagina a raspuns cu:", missing.status_code)
        # Unele site-uri raspund cu 200 si pentru o cale necunoscuta.
    except requests.HTTPError:
        print("Pagina ceruta nu poate fi accesata. Cod:", missing.status_code)


def exercise_11(response):
    """Parcurg perechile nume-valoare din antete."""
    for name, value in response.headers.items():
        print(name + ": " + value)


def exercise_12(response):
    """Citesc antete cu o valoare implicita."""
    print("Server:", response.headers.get("Server", "lipseste"))
    print("Content-Type:", response.headers.get("Content-Type", "lipseste"))
    print("content-type:", response.headers.get("content-type", "lipseste"))
    # Antetele HTTP nu depind de majuscule. Cele doua chei dau aceeasi valoare.


def exercise_13(response):
    """Numar aparitiile cyber, indiferent de majuscule."""
    print("Aparitii cyber:", response.text.lower().count("cyber"))
    # lower returneaza tot un sir, pe care pot apela apoi count.


def exercise_14(response):
    """Extrag titlul prin find si slicing."""
    html = response.text
    start = html.lower().find("<title>")
    if start == -1:
        print("Titlu lipsa")
        return
    start = start + len("<title>")
    end = html.lower().find("</title>", start)
    if end == -1:
        print("Titlu lipsa")
        return
    print("Titlu:", html[start:end].strip())


def exercise_15(response):
    """Numar liniile si gasesc cea mai lunga linie."""
    lines = response.text.splitlines()
    print("Linii:", len(lines))
    if lines:
        print("Lungimea maxima:", len(max(lines, key=len)))
    else:
        print("Lungimea maxima: 0")


def exercise_16(response):
    """Verific schema URL-ului final."""
    if response.url.startswith("https://"):
        print("Conexiune securizata")
    else:
        print("Conexiune nesecurizata")
    # Verific doar folosirea HTTPS, nu securitatea completa a site-ului.


def exercise_17():
    """Afisez redirectionarile pornind de la HTTP."""
    response = fetch("http://cybercor.org")
    for previous in response.history:
        print(previous.status_code, previous.url)
    print("URL final:", response.url, "Cod:", response.status_code)


def exercise_18():
    """Compar corpurile raspunsurilor HEAD si GET."""
    time.sleep(1)
    head = requests.head(BASE_URL, timeout=TIMEOUT)
    get = fetch(BASE_URL)
    print("HEAD:", len(head.content), "octeti")
    print("GET:", len(get.content), "octeti")
    # HEAD primeste antetele, fara corp; GET primeste si continutul paginii.


def exercise_19(response):
    """Afisez numele si marcajul secure al cookie-urilor."""
    if not response.cookies:
        print("Niciun cookie setat")
    for cookie in response.cookies:
        print(cookie.name, cookie.secure)


def exercise_20():
    """Testez User-Agent printr-o sesiune pe httpbin."""
    with requests.Session() as session:
        session.headers.update({"User-Agent": "WebLab-Volcova-Natalia"})
        time.sleep(1)
        response = session.get(ECHO_URL + "/headers", timeout=TIMEOUT)
        response.raise_for_status()
        data = response.json()
        received = data["headers"].get("User-Agent")
        print("User-Agent primit:", received)
        print("Antet confirmat:", received == "WebLab-Volcova-Natalia")
    # text este un atribut deja disponibil; json() este o metoda care
    # interpreteaza corpul ca JSON si returneaza un obiect Python.


if __name__ == "__main__":
    # Refolosesc raspunsul pentru exercitiile care analizeaza aceeasi pagina.
    try:
        page = fetch(BASE_URL)
        exercises = [exercise_9, exercise_10, exercise_11, exercise_12,
                     exercise_13, exercise_14, exercise_15, exercise_16]
        for number, exercise in enumerate(exercises, 9):
            run_exercise(number, exercise, page)
        run_exercise(19, exercise_19, page)
    except requests.RequestException as error:
        print("Nu am putut descarca pagina:", error)
    run_exercise(17, exercise_17)
    run_exercise(18, exercise_18)
    run_exercise(20, exercise_20)
