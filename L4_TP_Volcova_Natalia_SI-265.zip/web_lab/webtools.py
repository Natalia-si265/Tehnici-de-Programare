# Laborator: functii, metode si importuri pe web
# Student: Volcova Natalia, SI-265
import requests
import time
import re
import json
import csv
import socket
import ssl
import hashlib
from datetime import datetime, timezone
from urllib.parse import urlparse, urljoin
from html import unescape
from html.parser import HTMLParser
from pathlib import Path

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10
DEFAULT_HEADERS = {"User-Agent": "WebLab-Volcova-Natalia"}
FOLDER = Path(__file__).resolve().parent
PATHS = ["/", "/robots.txt", "/sitemap.xml"]
SECURITY_HEADERS = [
    "Strict-Transport-Security", "Content-Security-Policy",
    "X-Frame-Options", "X-Content-Type-Options", "Referrer-Policy"
]


def allowed_url(url):
    """Verific adresele indicate in enunt inainte de a trimite o cerere."""
    if not isinstance(url, str):
        raise requests.exceptions.InvalidURL("Adresa trebuie sa fie text.")
    parsed = urlparse(url)
    paths = ["", "/", "/robots.txt", "/sitemap.xml", "/this-page-does-not-exist"]
    if parsed.hostname == "cybercor.org" and parsed.path in paths:
        if parsed.scheme in ["http", "https"] and not parsed.query:
            return
    if parsed.hostname == "httpbin.org" and parsed.path == "/headers":
        if parsed.scheme == "https":
            return
    if url == "https://this-domain-does-not-exist.invalid":
        return
    raise requests.exceptions.InvalidURL("Folosesc numai adresele din laborator.")


def fetch(url, timeout=10):
    """Descarc o pagina si returnez obiectul Response; exercitiile 21 si 23."""
    allowed_url(url)
    time.sleep(1)
    # Ex. 47 cere folosirea constantei in fetch, iar regulile generale cer
    # ca antetele personalizate sa fie testate doar pe httpbin.org.
    # Aplic antetul personalizat numai serviciului de testare.
    if urlparse(url).hostname == "httpbin.org":
        return requests.get(url, headers=DEFAULT_HEADERS, timeout=timeout)
    return requests.get(url, timeout=timeout)


def get_status(url: str) -> int:
    """Returnez codul de stare HTTP; exercitiile 22 si 26."""
    response = fetch(url)
    return response.status_code


def get_title(html: str) -> str:
    """Extrag titlul din HTML, fara sa descarc pagina; exercitiile 24 si 25."""
    lower_html = html.lower()
    start = lower_html.find("<title>")
    if start == -1:
        return "Titlu lipsa"
    start = start + len("<title>")
    end = lower_html.find("</title>", start)
    if end == -1:
        return "Titlu lipsa"
    return unescape(html[start:end].strip())


def page_exists(url):
    """Returnez False si la o eroare de conectare; exercitiul 27."""
    try:
        response = fetch(url)
        return response.ok
    except requests.RequestException:
        return False


def check_paths(base, paths):
    """Returnez codurile pentru cai; None inseamna eroare de retea; ex. 28."""
    results = {}
    for path in paths:
        try:
            results[path] = get_status(urljoin(base, path))
        except requests.RequestException as error:
            print("Nu am putut verifica", path, ":", error)
            results[path] = None
        # fetch include time.sleep(1) inaintea fiecarei cereri.
    return results


def get_header(url, name, default="lipseste"):
    """Returnez un antet sau valoarea implicita; exercitiul 29."""
    response = fetch(url)
    return response.headers.get(name, default)


def security_headers(url):
    """Verific prezenta celor cinci antete cerute; exercitiul 30."""
    response = fetch(url)
    response.raise_for_status()
    results = {}
    for header in SECURITY_HEADERS:
        results[header] = header in response.headers
    return results


def score_headers(results):
    """Numar antetele prezente si returnez scorul; exercitiul 31."""
    present = 0
    for value in results.values():
        if value:
            present = present + 1
    return str(present) + "/" + str(len(results))


def fetch_robots(base):
    """Returnez robots.txt sau None daca lipseste; exercitiul 32."""
    response = fetch(urljoin(base, "/robots.txt"))
    if response.status_code == 404:
        return None
    response.raise_for_status()
    return response.text


def disallowed_paths(robots_text):
    """Extrag valorile Disallow, fara sa accesez aceste cai; exercitiul 32."""
    paths = []
    if robots_text is None:
        return paths
    for line in robots_text.splitlines():
        line = line.split("#", 1)[0].strip()
        if line.lower().startswith("disallow:"):
            value = line.split(":", 1)[1].strip()
            if value:
                paths.append(value)
    return paths


def response_times(*urls):
    """Masor durata fiecarei cereri, fara pauza de o secunda; exercitiul 33."""
    results = {}
    for url in urls:
        allowed_url(url)
        time.sleep(1)
        start = time.perf_counter()
        response = requests.get(url, timeout=TIMEOUT)
        duration = time.perf_counter() - start
        results[url] = duration
    return results


def log(message, **details):
    """Afisez mesajul si detaliile primite prin nume; exercitiul 34."""
    text = message
    for name, value in details.items():
        text = text + " | " + name + "=" + str(value)
    print(text)


def extract_links(html):
    """Extrag href cu expresia ceruta, fara duplicate; exercitiul 37."""
    found = re.findall(r'href="([^"]+)"', html)
    links = []
    for link in found:
        if link not in links:
            links.append(link)
    return links


def split_links(links, domain):
    """Separ legaturile HTTP/HTTPS dupa domeniu; exercitiul 38."""
    base = domain if "://" in domain else "https://" + domain
    hostname = urlparse(base).hostname
    internal = []
    external = []
    for link in links:
        absolute = urljoin(base, link)
        parsed = urlparse(absolute)
        # mailto:, tel: si javascript: nu sunt pagini web.
        if parsed.scheme not in ["http", "https"]:
            continue
        if parsed.hostname == hostname:
            if absolute not in internal:
                internal.append(absolute)
        elif absolute not in external:
            external.append(absolute)
    return internal, external


class ImageFinder(HTMLParser):
    """Colectez sursele imaginilor din HTML; exercitiul 39."""

    def __init__(self):
        """Pregatesc parserul si lista de imagini."""
        super().__init__()
        self.images = []

    def handle_starttag(self, tag, attrs):
        """Metoda este apelata de parser cand feed citeste un tag de inceput."""
        if tag == "img":
            src = dict(attrs).get("src")
            if src is not None:
                self.images.append(src)


def page_fingerprint(url):
    """Calculez SHA-256 pentru octetii paginii; exercitiul 40."""
    response = fetch(url)
    response.raise_for_status()
    return hashlib.sha256(response.content).hexdigest()


def resolve(hostname):
    """Returnez adresa IPv4 a domeniului din laborator; exercitiul 42."""
    if hostname != "cybercor.org":
        raise ValueError("Domeniul laboratorului este cybercor.org.")
    return socket.gethostbyname(hostname)


def cert_days_left(hostname):
    """Citesc certificatul TLS si calculez zilele ramase; exercitiul 43."""
    if hostname != "cybercor.org":
        raise ValueError("Domeniul laboratorului este cybercor.org.")
    context = ssl.create_default_context()
    time.sleep(1)
    with socket.create_connection((hostname, 443), timeout=TIMEOUT) as sock:
        with context.wrap_socket(sock, server_hostname=hostname) as connection:
            certificate = connection.getpeercert()
    expiry = ssl.cert_time_to_seconds(certificate["notAfter"])
    now = datetime.now(timezone.utc).timestamp()
    return int((expiry - now) // (24 * 60 * 60))


def save_csv(results):
    """Salvez caile, codurile si ora verificarii in report.csv; exercitiul 49."""
    checked_at = datetime.now().isoformat()
    with open(FOLDER / "report.csv", "w", newline="", encoding="utf-8") as file:
        writer = csv.writer(file)
        writer.writerow(["path", "status", "checked_at"])
        for path, status in results.items():
            writer.writerow([path, status, checked_at])


def site_report(url):
    """Colectez, afisez si salvez informatiile site-ului; exercitiul 50."""
    allowed_url(url)
    if urlparse(url).hostname != "cybercor.org":
        raise ValueError("Raportul laboratorului foloseste cybercor.org.")
    report = {
        "student": "Volcova Natalia", "grupa": "SI-265", "url": url,
        "checked_at": datetime.now().isoformat(),
        "status_code": None, "final_url": None, "title": None,
        "ip": None, "redirects": None, "security_headers": None,
        "security_score": None, "certificate_days_left": None,
        "internal_links": None, "external_links": None,
        "disallowed_paths": None, "errors": []
    }
    try:
        response = fetch(url)
        report["status_code"] = response.status_code
        report["final_url"] = response.url
        response.raise_for_status()
        report["title"] = get_title(response.text)
        links = extract_links(response.text)
        internal, external = split_links(links, response.url)
        report["internal_links"] = len(internal)
        report["external_links"] = len(external)
    except requests.RequestException as error:
        report["errors"].append("Pagina: " + str(error))
    try:
        report["ip"] = resolve("cybercor.org")
    except OSError as error:
        report["errors"].append("DNS: " + str(error))
    try:
        response = fetch("http://cybercor.org")
        report["redirects"] = []
        for previous in response.history:
            report["redirects"].append({
                "status": previous.status_code, "url": previous.url,
                "location": previous.headers.get("Location")
            })
        report["redirect_final_url"] = response.url
        response.raise_for_status()
    except requests.RequestException as error:
        report["errors"].append("Redirectionari: " + str(error))
    try:
        results = security_headers(url)
        report["security_headers"] = results
        report["security_score"] = score_headers(results)
    except requests.RequestException as error:
        report["errors"].append("Antete: " + str(error))
    try:
        report["certificate_days_left"] = cert_days_left("cybercor.org")
    except (OSError, ValueError, KeyError) as error:
        report["errors"].append("Certificat: " + str(error))
    try:
        robots = fetch_robots(url)
        report["disallowed_paths"] = disallowed_paths(robots)
    except requests.RequestException as error:
        report["errors"].append("robots.txt: " + str(error))
    print("=== Raport site:", url, "===")
    for name, value in report.items():
        if name != "errors":
            print(name + ":", value)
    for error in report["errors"]:
        print("Nu am putut obtine:", error)
    with open(FOLDER / "report.json", "w", encoding="utf-8") as file:
        json.dump(report, file, indent=2, ensure_ascii=False)
    print("Salvat in report.json")
    return report


def run_exercise(number, action, *args):
    """Rulez o demonstratie fara sa opresc restul la o eroare de retea."""
    print("\n--- Exercitiul", number, "---")
    try:
        action(*args)
    except (requests.RequestException, OSError, ValueError) as error:
        print("Nu am putut termina exercitiul:", error)


if __name__ == "__main__":
    # Ex. 46: __name__ este __main__ numai daca pornesc acest fisier direct.
    # Cand import webtools, functiile sunt disponibile, dar autotestul nu ruleaza.
    try:
        print("Autotest:", get_status(BASE_URL))
    except requests.RequestException as error:
        print("Autotest: conexiunea nu a reusit:", error)
