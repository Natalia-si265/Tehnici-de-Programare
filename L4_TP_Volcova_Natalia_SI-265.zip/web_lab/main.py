# Laborator: functii, metode si importuri pe web
# Student: Volcova Natalia, SI-265
BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10

import argparse
import requests
import webtools
from webtools import get_title, security_headers, DEFAULT_HEADERS

# Ex. 44: import webtools pastreaza numele modulului la fiecare apel.
# Exemplu: webtools.get_title(webtools.fetch(BASE_URL).text).
# Ex. 45: from ... import ... permite apelul direct get_title(html).
# Daca definesc si aici get_title, ultimul nume atribuit il inlocuieste pe
# primul. Pentru a evita confuzia, pot folosi webtools.get_title.
# Ex. 46: importul nu executa autotestul din blocul __main__ al webtools.
# Ex. 47: import constanta si o afisez; in fetch este folosita pe httpbin.


def main():
    """Citesc URL-ul din linia de comanda si creez rapoartele CSV si JSON."""
    # Ex. 48: python main.py https://cybercor.org
    parser = argparse.ArgumentParser(description="Raportul site-ului pentru L4")
    parser.add_argument("url", nargs="?", default=BASE_URL)
    args = parser.parse_args()
    if args.url not in [BASE_URL, BASE_URL + "/"]:
        parser.error("Pentru acest laborator folosesc https://cybercor.org.")
    print("Student: Volcova Natalia, SI-265")
    print("DEFAULT_HEADERS:", DEFAULT_HEADERS)
    try:
        # Ex. 44 si 45: demonstrez ambele stiluri, cu acelasi raspuns.
        response = webtools.fetch(args.url)
        response.raise_for_status()
        print("Ex. 44, prin modul:", webtools.get_title(response.text))
        print("Ex. 45, import direct:", get_title(response.text))
        print("Antete:", security_headers(args.url))
    except requests.RequestException as error:
        print("Nu am putut obtine pagina:", error)
    # Ex. 49: salvez dictionarul in CSV cu ora verificarii.
    results = webtools.check_paths(args.url, webtools.PATHS)
    webtools.save_csv(results)
    print("Salvat in report.csv")
    # Ex. 50: raportul foloseste functiile modulului meu.
    webtools.site_report(args.url)


if __name__ == "__main__":
    main()
