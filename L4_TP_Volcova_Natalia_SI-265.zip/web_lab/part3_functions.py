# Laborator: functii, metode si importuri pe web
# Student: Volcova Natalia, SI-265
BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10

import requests
from webtools import (fetch, get_status, get_title, page_exists, check_paths,
                      get_header, security_headers, score_headers, fetch_robots,
                      disallowed_paths, response_times, log, run_exercise)

# La exercitiul 44 am mutat functiile reutilizabile in webtools.py.
# Aici pastrez apelurile pentru exercitiile 21-34.


def exercise_21():
    """Apelez fetch si citesc codul raspunsului."""
    print(fetch(BASE_URL).status_code)


def exercise_22():
    """Apelez get_status pentru cele trei cai permise."""
    for path in ["/", "/robots.txt", "/sitemap.xml"]:
        print(path, get_status(BASE_URL + path))
        # fetch face pauza time.sleep(1) inaintea fiecarei cereri.


def exercise_23():
    """Folosesc parametrul implicit si un timeout ales de mine."""
    print("Implicit:", fetch(BASE_URL).status_code)
    print("timeout=3:", fetch(BASE_URL, timeout=3).status_code)


def exercise_24():
    """Separ descarcarea de extragerea titlului."""
    response = fetch(BASE_URL)
    print(get_title(response.text))


def exercise_25():
    """Afisez documentatia functiei mele."""
    help(get_title)


def exercise_26():
    """Observ ca adnotarile nu verifica automat tipul argumentului."""
    print("Adnotari:", get_status.__annotations__)
    try:
        get_status(123)
    except requests.RequestException as error:
        print("Argument invalid:", error)
    # Adnotarile descriu tipurile. Eroarea vine din codul care foloseste
    # argumentul ca URL, nu din adnotarea url: str.


def exercise_27():
    """Verific si adresa invalida indicata de profesor."""
    print("Pagina principala:", page_exists(BASE_URL))
    print("Domeniu inexistent:", page_exists("https://this-domain-does-not-exist.invalid"))


def exercise_28():
    """Primesc un dictionar cu rezultatele pentru cai."""
    print(check_paths(BASE_URL, ["/", "/robots.txt", "/sitemap.xml"]))


def exercise_29():
    """Folosesc argumentul cu nume name."""
    print(get_header(BASE_URL, name="Server"))


def exercise_30():
    """Afisez prezenta antetelor de securitate."""
    print(security_headers(BASE_URL))


def exercise_31():
    """Transmit rezultatul unei functii catre alta."""
    print(score_headers(security_headers(BASE_URL)))


def exercise_32():
    """Descarc robots.txt si extrag regulile Disallow."""
    robots = fetch_robots(BASE_URL)
    print(disallowed_paths(robots))
    print("Pentru None:", disallowed_paths(None))


def exercise_33():
    """Transmit doua URL-uri prin *urls."""
    print(response_times(BASE_URL, BASE_URL + "/robots.txt"))


def exercise_34():
    """Transmit detalii cu nume prin **details."""
    status = get_status(BASE_URL)
    log("verificat", url=BASE_URL, status=status)
    # print afiseaza, return transmite o valoare pe care o pot folosi mai departe.


if __name__ == "__main__":
    exercises = [exercise_21, exercise_22, exercise_23, exercise_24,
                 exercise_25, exercise_26, exercise_27, exercise_28,
                 exercise_29, exercise_30, exercise_31, exercise_32,
                 exercise_33, exercise_34]
    for number, exercise in enumerate(exercises, 21):
        run_exercise(number, exercise)
