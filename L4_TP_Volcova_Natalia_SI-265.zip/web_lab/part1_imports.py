# Laborator: functii, metode si importuri pe web
# Student: Volcova Natalia, SI-265
BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10

import requests
import urllib.request
import time
from requests import get
import requests as rq
from webtools import run_exercise


def exercise_1():
    """Afisez versiunea bibliotecii externe."""
    print("requests:", requests.__version__)
    # requests este o biblioteca externa, de aceea o instalez cu pip.
    # urllib face parte din biblioteca standard instalata cu Python.
    # Modulul este o unitate de cod importabila, de obicei un fisier .py.
    # Un pachet grupeaza module; o biblioteca ofera cod pentru un domeniu.


def exercise_2():
    """Compar importul modulului cu importul unei functii."""
    time.sleep(1)
    response = requests.get(BASE_URL, timeout=TIMEOUT)
    print("requests.get:", response.status_code)
    time.sleep(1)
    response = get(BASE_URL, timeout=TIMEOUT)
    print("get:", response.status_code)
    # requests.get arata din ce biblioteca vine functia.
    # from requests import get imi permite sa scriu mai putin la apelare.


def exercise_3():
    """Folosesc aliasul rq pentru requests."""
    time.sleep(1)
    response = rq.get(BASE_URL, timeout=TIMEOUT)
    print("rq.get:", response.status_code)
    # Aliasul este util daca numele este lung si cunoscut de cei care citesc.
    # Un alias prea scurt sau neclar poate ascunde sensul importului.


def exercise_4():
    """Descarc pagina numai cu instrumente din biblioteca standard."""
    # La rularea mea, urllib a primit HTTP Error 403: Forbidden.
    # Cu requests am primit 200; cu urllib nu am putut citi pagina.
    time.sleep(1)
    with urllib.request.urlopen(BASE_URL, timeout=TIMEOUT) as response:
        print("Status:", response.status)
        html = response.read().decode("utf-8")
        print(html[:200])
    # read returneaza bytes; decode transforma octetii in text.


def exercise_5():
    """Inspectez numele disponibile in requests."""
    print(dir(requests))
    # get este o functie, Session este o clasa, iar exceptions este un modul.


def exercise_6():
    """Consult help si setez timeout."""
    help(requests.get)
    # timeout este transmis prin argumentele optionale **kwargs.
    # Limiteaza asteptarea conexiunii si a datelor; nu durata totala absoluta.
    time.sleep(1)
    response = requests.get(BASE_URL, timeout=TIMEOUT)
    print("Status cu timeout:", response.status_code)


def exercise_7():
    """Compar timpul masurat de mine cu timpul din raspuns."""
    time.sleep(1)
    start = time.perf_counter()
    response = requests.get(BASE_URL, timeout=TIMEOUT)
    duration = time.perf_counter() - start
    print("perf_counter:", duration, "secunde")
    print("response.elapsed:", response.elapsed.total_seconds(), "secunde")
    # Masurarea mea include si descarcarea corpului; elapsed masoara pana
    # la primirea antetelor. De aceea valorile nu trebuie sa fie egale.


def exercise_8():
    """Tratez lipsa unui modul optional."""
    try:
        import bs4
        print("bs4 este instalat:", bs4.__version__)
    except ImportError:
        print("Instalati modulul cu: pip install beautifulsoup4")


if __name__ == "__main__":
    exercises = [exercise_1, exercise_2, exercise_3, exercise_4,
                 exercise_5, exercise_6, exercise_7, exercise_8]
    for number, exercise in enumerate(exercises, 1):
        run_exercise(number, exercise)
