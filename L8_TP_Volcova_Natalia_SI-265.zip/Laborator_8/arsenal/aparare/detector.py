import argparse, json
from collections import Counter
from arsenal.aparare.parse_auth import citeste_esecuri, pe_ip

def suspecti(counts, prag=10):
    if prag < 1:
        raise ValueError("prag invalid: %s (cel putin 1)" % prag)
    return sorted(((ip, n) for ip, n in counts.items() if n >= prag),
                  key=lambda pereche: pereche[1], reverse=True)

def raport_json(cale, prag=10):
    esecuri = citeste_esecuri(cale)
    counts = pe_ip(esecuri)
    return {"esecuri": len(esecuri), "pe_ip": dict(counts),
            "suspecti": suspecti(counts, prag)}

def e_brute_force(counts, ip, prag=10):
    return counts.get(ip, 0) >= prag

def utilizatori_tintiti(esecuri, ip):
    return {e["user"] for e in esecuri if e["ip"] == ip}

def main():
    p = argparse.ArgumentParser()
    p.add_argument('log')
    p.add_argument('--prag', type=int, default=10)
    p.add_argument('--json', action='store_true')
    a = p.parse_args()
    esecuri = citeste_esecuri(a.log)
    counts = pe_ip(esecuri)
    sus = suspecti(counts, a.prag)
    if a.json:
        print(json.dumps({'esecuri': len(esecuri),
                          'pe_ip': dict(counts),
                          'suspecti': sus}, indent=2))
        return
    print('Esecuri de autentificare:', len(esecuri))
    for ip, n in counts.most_common():
        print('  %s: %d' % (ip, n))
    print('Suspecti (prag %d):' % a.prag)
    for ip, n in sus:
        print('  %s  (%d incercari)  BRUTE FORCE' % (ip, n))

if __name__ == '__main__':
    main()
