import re
from collections import Counter

TIPAR = re.compile(r"Failed password for (?:invalid user )?(\S+) from (\S+) port")

def esec(linie):
    m = TIPAR.search(linie)
    if m is None:
        return None
    return m.group(1), m.group(2)

def citeste_esecuri(cale):
    esecuri = []
    try:
        with open(cale, encoding="utf-8") as fisier:
            for linie in fisier:
                rezultat = esec(linie)
                if rezultat is not None:
                    esecuri.append({"user": rezultat[0], "ip": rezultat[1]})
    except FileNotFoundError:
        print("Fisierul nu exista: %s" % cale)
        return []
    return esecuri

def pe_ip(esecuri):
    return Counter(e["ip"] for e in esecuri)

def rezumat(cale):
    esecuri = citeste_esecuri(cale)
    return {"esecuri": len(esecuri), "pe_ip": pe_ip(esecuri)}

def main():
    import sys
    cale = sys.argv[1] if len(sys.argv) > 1 else 'start/auth.log'
    esecuri = citeste_esecuri(cale)
    counts = pe_ip(esecuri)
    print('Esecuri de autentificare:', len(esecuri))
    for ip, n in counts.most_common():
        print('  %s: %d' % (ip, n))

if __name__ == '__main__':
    main()
