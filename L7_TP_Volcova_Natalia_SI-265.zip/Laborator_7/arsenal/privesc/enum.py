import argparse, io, json, os

GTFO = {'nmap', 'vim', 'perl', 'less', 'cp', 'vim.basic', 'bash', 'python3', 'awk', 'find'}

def citeste_linii(cale):

    with io.open(cale, encoding="utf-8") as fisier:
        randuri = [rand.strip() for rand in fisier]
    return [rand for rand in randuri if rand and not rand.startswith("#")]

def nume(cale):

    return cale.rsplit("/", 1)[-1]

def suid_constatari(cale):

    return [
        {"cale": c, "nume": nume(c),
         "risc": "mare" if nume(c) in GTFO else "normal"}
        for c in sorted(set(citeste_linii(cale)))
    ]

def sudo_constatari(cale):

    constatari = []
    for rand in citeste_linii(cale):
        user, drept = rand.split(" : ", 1)
        constatari.append({
            "user": user, "drept": drept,
            "risc": "mare" if "NOPASSWD" in drept else "normal"
        })
    return constatari

def cron_constatari(cale):

    constatari = []
    for rand in citeste_linii(cale):
        campuri = rand.split()
        constatari.append({"user": campuri[5],
                           "comanda": " ".join(campuri[6:])})
    return constatari

def enumereaza(dosar):

    return {
        "suid": suid_constatari(os.path.join(dosar, "suid.txt")),
        "sudo": sudo_constatari(os.path.join(dosar, "sudo.txt")),
        "cron": cron_constatari(os.path.join(dosar, "crontab.txt"))
    }

def utilizatori_implicati(raport):

    sudo = {constatare["user"] for constatare in raport["sudo"]}
    cron = {constatare["user"] for constatare in raport["cron"]}
    return sudo | cron

def cai(fisier):

    return set(citeste_linii(fisier))

def suid_noi(acum, baza):

    return acum - baza

def risc_pe_nume(multime_cai):

    return {nume(c): ("mare" if nume(c) in GTFO else "normal") for c in multime_cai}

def periculoase_noi(noi):

    return sorted(c for c in noi if nume(c) in GTFO)

def main():
    p = argparse.ArgumentParser()
    p.add_argument("capturi")
    p.add_argument("--json", action="store_true")
    a = p.parse_args()
    raport = enumereaza(a.capturi)
    if a.json:
        print(json.dumps(raport, indent=2, ensure_ascii=False))
        return
    for categorie, lista in raport.items():
        mari = [c for c in lista if c.get("risc") == "mare"]
        print("%s: %d gasite, %d cu risc mare" % (categorie, len(lista), len(mari)))
    useri = utilizatori_implicati(raport)
    print("utilizatori implicati:", ", ".join(sorted(useri)))
    with io.open("enum.json", "w", encoding="utf-8") as fis:
        json.dump(raport, fis, indent=2, ensure_ascii=False)
    print("Raport salvat in enum.json")

if __name__ == "__main__":
    main()
