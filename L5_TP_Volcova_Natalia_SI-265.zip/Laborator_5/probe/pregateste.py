
import os
import base64
import hashlib
import random
from urllib.parse import quote
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))


def scrie(nume, date):
    cale = os.path.join(HERE, nume)
    mod = "wb" if isinstance(date, (bytes, bytearray)) else "w"
    with open(cale, mod, encoding=(None if "b" in mod else "utf-8")) as f:
        f.write(date)
    print("  scris:", nume)


clar = b"FLAG{straturi_de_encoding}"
strat_hex = clar.hex().encode()              # text hex, ca octeti
strat_b64_1 = base64.b64encode(strat_hex)    # base64 peste hex
strat_b64_2 = base64.b64encode(strat_b64_1)  # inca un base64 deasupra
scrie("mesaj.txt", strat_b64_2.decode())

secret = b"Un singur octet tine tot secretul... gaseste-l! FLAG{xor_un_octet}"
K = 0x80
scrie("xor.bin", bytes(b ^ K for b in secret))

parole = ["password", "dragon", "qwerty", "letmein", "monkey"]
wordlist = ["123456", "football", "iloveyou"] + parole + ["admin", "welcome"]
random.seed(6); random.shuffle(wordlist)
scrie("hashuri.txt", "\n".join(hashlib.md5(p.encode()).hexdigest() for p in parole) + "\n")
scrie("wordlist.txt", "\n".join(wordlist) + "\n")

img = Image.new("RGB", (640, 480), (70, 110, 160))
exif = Image.Exif()
exif[0x010F] = "Apple"                     # Make
exif[0x0110] = "iPhone 13"                 # Model
exif[0x0132] = "2026:09:14 10:30:00"       # DateTime
exif[0x8825] = {
    1: "N", 2: (47.0, 1.0, 0.0),
    3: "E", 4: (28.0, 51.0, 27.0),
}
img.save(os.path.join(HERE, "foto.jpg"), exif=exif, quality=90)
print("  scris: foto.jpg")

png_path = os.path.join(HERE, "ascuns.png")
Image.new("RGB", (320, 240), (40, 160, 90)).save(png_path)
import zipfile, io
buf = io.BytesIO()
with zipfile.ZipFile(buf, "w") as z:
    z.writestr("secret.txt", "FLAG{ascuns_prin_carving}\n")
with open(png_path, "ab") as f:
    f.write(buf.getvalue())
print("  adaugat ZIP la coada: ascuns.png")

