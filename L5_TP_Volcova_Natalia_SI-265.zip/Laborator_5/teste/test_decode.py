import unittest
import hashlib
import tempfile
from pathlib import Path
from PIL import Image
from arsenal.forensics.decode import desfa, ghici_strat, decodeaza, xor, sparge_hash
from forensics import grade
from stego import ascunde, dezvaluie


def test_base64():
    strat, b = desfa('U2FsdXQ=')
    assert strat == 'base64'
    assert b == b'Salut'


class TestLaborator(unittest.TestCase):
    def test_base64(self):
        test_base64()

    def test_clasificare(self):
        self.assertEqual(ghici_strat('%2Fetc'), 'url')
        self.assertEqual(ghici_strat('48656c6c6f'), 'hex')
        self.assertEqual(ghici_strat('abc==='), 'necunoscut')

    def test_straturi(self):
        r = decodeaza(Path('probe/mesaj.txt').read_bytes())
        self.assertEqual(r['strat'], ['base64', 'base64', 'hex'])
        self.assertEqual(r['rezultat'], 'FLAG{straturi_de_encoding}')

    def test_xor(self):
        self.assertEqual(xor(Path('probe/xor.bin').read_bytes())[0]['cheie'], 128)

    def test_hash(self):
        for alg in ('md5', 'sha1', 'sha256'):
            h = hashlib.new(alg, b'dragon').hexdigest()
            self.assertEqual(sparge_hash(h, ['gresit', 'dragon'])['parola'], 'dragon')
            self.assertIsNone(sparge_hash(h, ['gresit'])['parola'])

    def test_gps(self):
        self.assertAlmostEqual(grade((47, 1, 0), 'N'), 47.0166666667)
        self.assertEqual(grade((28, 51, 27), 'W'), -28.8575)

    def test_lsb(self):
        with tempfile.TemporaryDirectory() as tmp:
            src, dst = Path(tmp) / 'src.png', Path(tmp) / 'dst.png'
            Image.new('RGB', (20, 20), (70, 110, 160)).save(src)
            for text in ('', 'FLAG{ascuns_in_pixeli}', 'șțîăâ'):
                ascunde(src, dst, text)
                self.assertEqual(dezvaluie(dst), text)
            with self.assertRaises(ValueError):
                ascunde(src, dst, 'x' * 200)


if __name__ == '__main__':
    unittest.main()
