import argparse
import io
import json
import re
import zipfile
from pathlib import Path
from PIL import Image
from PIL.ExifTags import TAGS


def tip_real(cale):
    with open(cale, 'rb') as f:
        cap = f.read(8)
    for semn, tip in [(b'%PDF', 'pdf'), (b'\x89PNG\r\n\x1a\n', 'png'), (b'\xff\xd8', 'jpeg'), (b'PK\x03\x04', 'zip/docx')]:
        if cap.startswith(semn):
            return tip
    return 'necunoscut: ' + cap.hex()


def grade(v, emisfera):
    r = float(v[0]) + float(v[1]) / 60 + float(v[2]) / 3600
    return -r if emisfera in ('S', 'W') else r


def analizeaza(probe, output):
    output.mkdir(exist_ok=True, parents=True)
    with Image.open(probe / 'foto.jpg') as img:
        exif = img.getexif()
        meta = {TAGS.get(k, str(k)): str(v) for k, v in exif.items() if k != 34853}
        gps = exif.get_ifd(34853)
        meta['GPS'] = {'latitudine': grade(gps[2], gps[1]), 'longitudine': grade(gps[4], gps[3])}
    date = (probe / 'ascuns.png').read_bytes()
    poz = 8
    while poz + 12 <= len(date):
        lungime = int.from_bytes(date[poz:poz+4], 'big')
        tip = date[poz+4:poz+8]
        poz += 12 + lungime
        if tip == b'IEND':
            break
    offset = date.find(b'PK\x03\x04', poz)
    if offset < 0:
        raise ValueError('Arhiva lipseste')
    arhiva = date[offset:]
    (output / 'gasit.zip').write_bytes(arhiva)
    with zipfile.ZipFile(io.BytesIO(arhiva)) as z:
        secret = z.read('secret.txt').decode()
    (output / 'secret.txt').write_text(secret, encoding='utf-8')
    return {'tipuri': {'foto.jpg': tip_real(probe / 'foto.jpg'), 'ascuns.png': tip_real(probe / 'ascuns.png'), 'gasit.zip': tip_real(output / 'gasit.zip')}, 'strings': [s.decode() for s in re.findall(rb'[ -~]{4,}', date)], 'metadate': meta, 'offset_zip': offset, 'secret': secret.strip()}


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--probe', type=Path, default=Path('probe'))
    p.add_argument('--output', type=Path, default=Path('output'))
    a = p.parse_args()
    print(json.dumps(analizeaza(a.probe, a.output), ensure_ascii=False, indent=2))
