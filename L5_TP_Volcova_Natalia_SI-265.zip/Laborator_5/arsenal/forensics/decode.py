import argparse
import base64
import hashlib
import json
import re
from pathlib import Path
from urllib.parse import unquote_to_bytes


def citibil(b):
    return bool(b) and all(32 <= x < 127 for x in b)


def ghici_strat(s):
    s = s.strip()
    if re.search(r'%[0-9a-fA-F]{2}', s):
        return 'url'
    if s and len(s) % 2 == 0 and re.fullmatch(r'[0-9a-fA-F]+', s):
        return 'hex'
    if s and len(s) % 4 == 0 and re.fullmatch(r'[A-Za-z0-9+/]+={0,2}', s):
        try:
            base64.b64decode(s, validate=True)
            return 'base64'
        except ValueError:
            pass
    return 'necunoscut'


def desfa(s):
    tip = ghici_strat(s)
    if tip == 'url':
        return tip, unquote_to_bytes(s)
    if tip == 'hex':
        return tip, bytes.fromhex(s.strip())
    if tip == 'base64':
        return tip, base64.b64decode(s.strip(), validate=True)
    return tip, s.encode()


def xor(date):
    candidati = []
    for k in range(256):
        b = bytes(x ^ k for x in date)
        if citibil(b):
            text = b.decode('ascii')
            scor = 1000 * ('FLAG{' in text) + sum(c.isalpha() or c == ' ' for c in text)
            candidati.append((scor, k, text))
    return [{'cheie': k, 'text': t} for _, k, t in sorted(candidati, reverse=True)]


def decodeaza(date):
    straturi = []
    vazute = {date}
    for _ in range(8):
        try:
            text = date.decode('ascii').strip()
        except UnicodeDecodeError:
            text = None
        if text is not None and text.startswith('FLAG{'):
            break
        tip, nou = desfa(text) if text is not None else ('necunoscut', date)
        if tip == 'necunoscut':
            if not citibil(date):
                c = xor(date)
                if c:
                    return {'strat': straturi + ['xor'], 'rezultat': c[0]['text'], 'cheie': c[0]['cheie']}
            break
        if nou in vazute:
            break
        straturi.append(tip)
        vazute.add(nou)
        date = nou
    return {'strat': straturi, 'rezultat': date.decode('utf-8', errors='backslashreplace')}


def sparge_hash(h, cuvinte):
    h = h.strip().lower()
    algoritm = {32: 'md5', 40: 'sha1', 64: 'sha256'}.get(len(h))
    if not algoritm or not re.fullmatch(r'[0-9a-f]+', h):
        raise ValueError('Hash nerecunoscut')
    for cuvant in cuvinte:
        cuvant = cuvant.rstrip('\r\n')
        if hashlib.new(algoritm, cuvant.encode()).hexdigest() == h:
            return {'algoritm': algoritm, 'hash': h, 'parola': cuvant}
    return {'algoritm': algoritm, 'hash': h, 'parola': None}


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('intrare')
    p.add_argument('--fisier', action='store_true')
    p.add_argument('--xor', action='store_true')
    p.add_argument('--wordlist', type=Path)
    p.add_argument('--iesire', type=Path, default=Path(__file__).with_name('fisa.json'))
    a = p.parse_args()
    date = Path(a.intrare).read_bytes() if a.fisier else a.intrare.encode()
    if a.wordlist:
        cuvinte = a.wordlist.read_text(encoding='utf-8').splitlines()
        r = {'strat': ['hash'], 'rezultat': [sparge_hash(h, cuvinte) for h in date.decode().splitlines() if h.strip()]}
    elif a.xor:
        r = {'strat': ['xor'], 'rezultat': xor(date)}
    else:
        r = decodeaza(date)
    a.iesire.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(r, ensure_ascii=False, indent=2)
    a.iesire.write_text(text + '\n', encoding='utf-8')
    print(text)
