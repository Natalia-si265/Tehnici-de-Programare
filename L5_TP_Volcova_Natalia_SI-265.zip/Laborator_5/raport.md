# Laboratorul 5
## Forensics și steganografie

### Scop

Realizarea unui decoder pentru codări uzuale, analiza fișierelor și ascunderea unui mesaj în pixeli.

### Rulare

Din folderul Laborator_5:

```console
python -m pip install pillow
python probe/pregateste.py
```

Rezultatele rulării sunt în output/executie.txt. Comenzile pentru fiecare exercițiu sunt prezentate mai jos.

## Lucrarea A

### A1 Text și octeți

Pentru Salut, reprezentarea este b'Salut'. Primul octet are valoarea 83, iar forma hexazecimală este 53616c7574. Conversia bytes.fromhex reface textul inițial.

### A2–A4 Decodarea straturilor

Funcția ghici_strat verifică întâi URL, apoi hex și Base64. Funcția desfa returnează tipul și rezultatul în bytes. Decodarea se repetă cel mult de opt ori, deoarece un rezultat intermediar poate fi încă un șir codat. Identificarea după alfabet este euristică și poate fi ambiguă pentru unele șiruri.

```console
python arsenal/forensics/decode.py probe/mesaj.txt --fisier
```

Ordinea straturilor este Base64 → Base64 → hex. Mesajul final:

```text
FLAG{straturi_de_encoding}
```

Fișa rezultatului este în arsenal/forensics/fisa.json.

### A5 XOR

```console
python arsenal/forensics/decode.py probe/xor.bin --fisier --xor --iesire output/xor.json
```

Au fost încercate toate cele 256 de chei. Cheia găsită este 128, adică 0x80. Mesajul:

```text
Un singur octet tine tot secretul... gaseste-l! FLAG{xor_un_octet}
```

Mai multe chei pot produce caractere imprimabile. Programul afișează mai întâi rezultatul care conține marcajul FLAG.

### A6 Hashuri și dicționar

```console
python arsenal/forensics/decode.py probe/hashuri.txt --fisier --wordlist probe/wordlist.txt --iesire output/hashuri.json
```

Hashurile din probă au 32 de caractere și sunt tratate ca MD5. Fiecare cuvânt este hashuit și comparat cu ținta. Lungimea este un indiciu pentru algoritm, nu o identificare garantată.

| Hash MD5 | Parolă |
| --- | --- |
| 5f4dcc3b5aa765d61d8327deb882cf99 | password |
| 8621ffdbc5698829397d97767ac13db3 | dragon |
| d8578edf8458ce06fbc5bb76a58c5ca4 | qwerty |
| 0d107d09f5bbe40cade3de5c71e9e9b7 | letmein |
| d0763edaa9d9bd2a9516280e9044d885 | monkey |

### A7 Testare

```console
python -c "from teste.test_decode import test_base64; test_base64()"
```

Testul Base64 cerut la A7 a trecut: U2FsdXQ= este decodat în Salut.

## Lucrarea B

### B1 Semnături

| Fișier | Semnătură | Tip |
| --- | --- | --- |
| foto.jpg | FF D8 | JPEG |
| ascuns.png | 89 50 4E 47 0D 0A 1A 0A | PNG |
| gasit.zip | 50 4B 03 04 | ZIP |

### B2 Șiruri imprimabile

În ascuns.png au fost identificate IHDR, IDATx, IEND, secret.txt și FLAG{ascuns_prin_carving}.

### B3 EXIF și GPS

| Câmp | Valoare |
| --- | --- |
| Make | Apple |
| Model | iPhone 13 |
| DateTime | 2026:09:14 10:30:00 |
| Latitudine | 47.016666666666666 N |
| Longitudine | 28.8575 E |

Conversia folosită este grade + minute/60 + secunde/3600. Pentru sud și vest se schimbă semnul. Metadatele sunt introduse artificial de generator, cu coordonate pentru Chișinău.

### B4 Extragerea arhivei

```console
python forensics.py
```

Arhiva ZIP începe la offsetul 782, după sfârșitul imaginii PNG. A fost salvată în output/gasit.zip. Fișierul secret.txt a fost recuperat în output/secret.txt și conține:

```text
FLAG{ascuns_prin_carving}
```

### B5–B6 Steganografie LSB

```console
python stego.py ascunde probe/foto.jpg stego.png "FLAG{ascuns_in_pixeli}"
python stego.py dezvaluie stego.png
```

Biții mesajului sunt scriși în ultimul bit al canalelor R, G și B. La final se adaugă un octet zero, folosit ca terminator la citire. Se verifică dacă mesajul încape în imagine. Rezultatul este salvat PNG pentru păstrarea biților.

Mesajul recuperat:

```text
FLAG{ascuns_in_pixeli}
```

## Concluzii

Au fost recuperate mesajul codat, cheia XOR, cele cinci parole și fișierul ascuns în arhivă. Metadatele au oferit modelul dispozitivului, data și coordonatele GPS. Mesajul scris prin LSB a fost citit corect din stego.png.
