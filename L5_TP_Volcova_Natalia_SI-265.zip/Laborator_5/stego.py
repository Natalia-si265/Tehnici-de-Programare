import argparse
from pathlib import Path
from PIL import Image


def ascunde(sursa, destinatie, mesaj):
    date = mesaj.encode('utf-8')
    if b'\0' in date:
        raise ValueError('Mesajul contine octetul zero')
    if Path(destinatie).suffix.lower() != '.png':
        raise ValueError('Destinatia trebuie sa fie PNG')
    with Image.open(sursa) as original:
        img = original.convert('RGB')
    canale = bytearray(img.tobytes())
    date += b'\0'
    if len(date) * 8 > len(canale):
        raise ValueError('Mesaj prea lung')
    for i in range(len(date) * 8):
        canale[i] = (canale[i] & 254) | ((date[i // 8] >> (7 - i % 8)) & 1)
    Image.frombytes('RGB', img.size, bytes(canale)).save(destinatie)


def dezvaluie(cale):
    with Image.open(cale) as img:
        canale = img.convert('RGB').tobytes()
    date = bytearray()
    for i in range(0, len(canale) - 7, 8):
        x = 0
        for c in canale[i:i+8]:
            x = (x << 1) | (c & 1)
        if x == 0:
            return date.decode('utf-8')
        date.append(x)
    raise ValueError('Terminator lipsa')


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    sub = p.add_subparsers(dest='comanda', required=True)
    h = sub.add_parser('ascunde')
    h.add_argument('sursa'); h.add_argument('destinatie'); h.add_argument('mesaj')
    d = sub.add_parser('dezvaluie'); d.add_argument('cale')
    a = p.parse_args()
    if a.comanda == 'ascunde':
        ascunde(a.sursa, a.destinatie, a.mesaj)
        print('Salvat:', a.destinatie)
    else:
        print(dezvaluie(a.cale))
