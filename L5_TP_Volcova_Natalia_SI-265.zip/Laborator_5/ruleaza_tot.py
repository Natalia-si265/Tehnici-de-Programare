import json
import os
import subprocess
import sys
from pathlib import Path
from arsenal.forensics.decode import decodeaza, sparge_hash
from forensics import analizeaza
from stego import ascunde, dezvaluie


def main():
    os.chdir(Path(__file__).resolve().parent)
    subprocess.run([sys.executable, 'probe/pregateste.py'], check=True)
    output = Path('output')
    output.mkdir(exist_ok=True)
    mesaj = decodeaza(Path('probe/mesaj.txt').read_bytes())
    Path('arsenal/forensics/fisa.json').write_text(json.dumps(mesaj, indent=2) + '\n', encoding='utf-8')
    cuvinte = Path('probe/wordlist.txt').read_text().splitlines()
    ascunde('probe/foto.jpg', 'stego.png', 'FLAG{ascuns_in_pixeli}')
    r = {'incalzire': {'bytes': str(b'Salut'), 'primul_octet': 83, 'hex': b'Salut'.hex(), 'refacut': bytes.fromhex('53616c7574').decode()}, 'mesaj': mesaj, 'xor': decodeaza(Path('probe/xor.bin').read_bytes()), 'hashuri': [sparge_hash(h, cuvinte) for h in Path('probe/hashuri.txt').read_text().splitlines()], 'forensics': analizeaza(Path('probe'), output), 'lsb': dezvaluie('stego.png')}
    text = json.dumps(r, ensure_ascii=False, indent=2)
    (output / 'executie.txt').write_text(text + '\n', encoding='utf-8')
    print(text)
    with (output / 'teste.txt').open('w', encoding='utf-8') as f:
        t = subprocess.run([sys.executable, '-m', 'unittest', 'discover', '-s', 'teste', '-v'], stdout=f, stderr=subprocess.STDOUT)
    print((output / 'teste.txt').read_text(encoding='utf-8'))
    raise SystemExit(t.returncode)


if __name__ == '__main__':
    main()
